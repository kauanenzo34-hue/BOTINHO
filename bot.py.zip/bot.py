import json
import os
import re
import shutil
import time
import zipfile
from datetime import datetime

import discord
from discord.ext import commands

try:
    import rarfile
except Exception:
    rarfile = None

TOKEN = "MTQ4Nzg5NDYxMTMzMzc0MjY3NA.GSAcoE.GWH6pE-vz80YCDzH7R6YooQMIhJz4pPejRbaHo"

BASE_PATH = os.path.join(os.getcwd(), "bots")
DATA_FILE = os.path.join(os.getcwd(), "host_data.json")

os.makedirs(BASE_PATH, exist_ok=True)

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

sessions = {}  # channel_id -> {"user_id": int, "language": str | None}
DATA = {
    "plans_configured": False,
    "users": {}
}


def load_data():
    global DATA
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                DATA = json.load(f)
            if "plans_configured" not in DATA:
                DATA["plans_configured"] = False
            if "users" not in DATA:
                DATA["users"] = {}
        except Exception:
            DATA = {"plans_configured": False, "users": {}}


def save_data():
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(DATA, f, ensure_ascii=False, indent=2)


load_data()


def sanitize_name(text: str, limit: int = 40) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9_\-]+", "-", text)
    text = re.sub(r"-{2,}", "-", text).strip("-")
    return text[:limit] or "usuario"


def ensure_user(user_id: int):
    uid = str(user_id)
    if uid not in DATA["users"]:
        DATA["users"][uid] = {
            "plan": "free",
            "bots": []
        }
        save_data()
    return DATA["users"][uid]


def find_user_bot(user_id: int, bot_id: str):
    user = DATA["users"].get(str(user_id), {})
    for b in user.get("bots", []):
        if b["id"] == bot_id:
            return b
    return None


def fake_ram():
    base = 72
    extra = int(time.time()) % 140
    return f"{base + extra}MB / 512MB"


def build_panel_embed():
    embed = discord.Embed(
        title="☁️ Peguen cloud",
        description=(
            "Gerencie seus bots de forma simples e rápida.\n\n"
            "🚀 Hospede bots\n"
            "📋 Gerencie seus bots\n"
            "⚡ Sistema rápido e automático"
        ),
        color=discord.Color.dark_blue()
    )
    embed.set_footer(text="Sistema de hospedagem • Beta")
    return embed


def build_deploy_step1_embed(user: discord.User):
    embed = discord.Embed(
        title="🚀 Deploy — Passo 1 de 4",
        description=(
            f"Olá {user.mention}!\n\n"
            "**Plano:** `Starter - Free`\n"
            f"**RAM disponível:** `100MB de 100MB`\n\n"
            "**Passo 1**\n"
            "Qual é a linguagem do seu bot?"
        ),
        color=discord.Color.dark_blue()
    )
    embed.set_footer(text="Phanom Cloud")
    return embed


def build_deploy_step2_embed(language: str):
    embed = discord.Embed(
        title="🚀 Deploy — Passo 2 de 4",
        description=(
            f"**Linguagem:** `{language}`\n\n"
            "📦 Agora envie o arquivo do bot em **.zip** ou **.rar**."
        ),
        color=discord.Color.green()
    )
    embed.set_footer(text="Phanom Cloud")
    return embed


def build_bot_embed(record: dict):
    status = "🟢 Online" if record.get("status") == "running" else "🔴 Offline"
    embed = discord.Embed(
        title="☁️ Phanom Cloud",
        description=(
            f"**Bot:** `{record['name']}`\n"
            f"**Status:** {status}\n"
            f"**RAM:** `{fake_ram()}`\n"
            f"**Linguagem:** `{record.get('language', 'desconhecida')}`\n"
            f"**Criado em:** `{record.get('created_at', '—')}`"
        ),
        color=discord.Color.dark_blue()
    )
    embed.set_footer(text="Sistema de hospedagem • Beta")
    return embed


def extract_archive(archive_path: str, target_dir: str):
    lower = archive_path.lower()
    if lower.endswith(".zip"):
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(target_dir)
        return

    if lower.endswith(".rar"):
        if rarfile is None:
            raise RuntimeError("RAR não suportado aqui. Use ZIP.")
        with rarfile.RarFile(archive_path) as rf:
            rf.extractall(target_dir)
        return

    raise RuntimeError("Formato inválido. Envie .zip ou .rar.")


def find_any_py(folder: str):
    py_files = []
    for root, _, files in os.walk(folder):
        for f in files:
            if f.endswith(".py") and not f.startswith(".") and f.lower() != "setup.py":
                py_files.append(os.path.join(root, f))

    if not py_files:
        return None

    priority = ["main.py", "bot.py", "app.py", "index.py"]
    for wanted in priority:
        for path in py_files:
            if path.endswith(wanted):
                return path

    return sorted(py_files)[0]


class LanguageSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="JavaScript (Node.js)", description="Mais popular para bots Discord", emoji="🟨"),
            discord.SelectOption(label="TypeScript", description="JavaScript com tipagem", emoji="🔷"),
            discord.SelectOption(label="Python", description="Simples e versátil", emoji="🐍"),
            discord.SelectOption(label="Go (Golang)", description="Rápido e eficiente", emoji="🔵"),
            discord.SelectOption(label="Java", description="Robusto e escalável", emoji="☕"),
            discord.SelectOption(label="PHP", description="Muito usado em bots web", emoji="🐘"),
            discord.SelectOption(label="Ruby", description="Elegante e produtivo", emoji="💎"),
        ]
        super().__init__(
            placeholder="Selecione a linguagem do bot...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        session = sessions.get(interaction.channel.id)
        if not session or session["user_id"] != interaction.user.id:
            await interaction.response.send_message("Essa etapa não é sua.", ephemeral=True)
            return

        session["language"] = self.values[0]
        await interaction.response.edit_message(embed=build_deploy_step2_embed(self.values[0]), view=None)


class LanguageView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=600)
        self.add_item(LanguageSelect())


class BotControlView(discord.ui.View):
    def __init__(self, user_id: int, bot_id: str):
        super().__init__(timeout=600)
        self.user_id = user_id
        self.bot_id = bot_id

    @discord.ui.button(label="Iniciar", style=discord.ButtonStyle.success, emoji="🚀")
    async def iniciar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Esse bot não é seu.", ephemeral=True)
            return

        record = find_user_bot(self.user_id, self.bot_id)
        if not record:
            await interaction.response.send_message("Bot não encontrado.", ephemeral=True)
            return

        record["status"] = "running"
        save_data()
        await interaction.response.send_message("Bot marcado como **online**.", ephemeral=True)

    @discord.ui.button(label="Parar", style=discord.ButtonStyle.danger, emoji="⛔")
    async def parar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Esse bot não é seu.", ephemeral=True)
            return

        record = find_user_bot(self.user_id, self.bot_id)
        if not record:
            await interaction.response.send_message("Bot não encontrado.", ephemeral=True)
            return

        record["status"] = "stopped"
        save_data()
        await interaction.response.send_message("Bot marcado como **offline**.", ephemeral=True)

    @discord.ui.button(label="Reiniciar", style=discord.ButtonStyle.primary, emoji="🔄")
    async def reiniciar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Esse bot não é seu.", ephemeral=True)
            return

        record = find_user_bot(self.user_id, self.bot_id)
        if not record:
            await interaction.response.send_message("Bot não encontrado.", ephemeral=True)
            return

        record["status"] = "running"
        record["restarted_at"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        save_data()
        await interaction.response.send_message("Bot reiniciado no painel.", ephemeral=True)

    @discord.ui.button(label="Apagar", style=discord.ButtonStyle.secondary, emoji="🗑️")
    async def apagar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Esse bot não é seu.", ephemeral=True)
            return

        record = find_user_bot(self.user_id, self.bot_id)
        if not record:
            await interaction.response.send_message("Bot não encontrado.", ephemeral=True)
            return

        folder = record.get("folder")
        try:
            if folder and os.path.exists(folder):
                shutil.rmtree(folder)
        except Exception:
            pass

        user = DATA["users"].get(str(self.user_id))
        if user:
            user["bots"] = [b for b in user["bots"] if b["id"] != self.bot_id]

        save_data()
        await interaction.response.send_message("Bot apagado do painel.", ephemeral=True)


class BotSelect(discord.ui.Select):
    def __init__(self, user_id: int, bots: list):
        self.user_id = user_id
        options = []
        for b in bots[:25]:
            status = "Rodando" if b.get("status") == "running" else "Parado"
            options.append(
                discord.SelectOption(
                    label=b["name"][:100],
                    value=b["id"],
                    description=f"{b.get('language', 'sem linguagem')} • {status}"
                )
            )

        super().__init__(placeholder="Selecione um bot...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        bot_id = self.values[0]
        record = find_user_bot(self.user_id, bot_id)
        if not record:
            await interaction.response.send_message("Bot não encontrado.", ephemeral=True)
            return

        await interaction.response.send_message(
            embed=build_bot_embed(record),
            view=BotControlView(self.user_id, bot_id),
            ephemeral=True
        )


class BotsListView(discord.ui.View):
    def __init__(self, user_id: int, bots: list):
        super().__init__(timeout=600)
        if bots:
            self.add_item(BotSelect(user_id, bots))
        else:
            self.add_item(discord.ui.Button(label="Sem bots", style=discord.ButtonStyle.secondary, disabled=True))


class MainPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🚀 Hospedar Bot", style=discord.ButtonStyle.primary)
    async def hospedar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.guild is None:
            await interaction.response.send_message("Use isso em um servidor.", ephemeral=True)
            return

        safe_user = sanitize_name(interaction.user.name)
        channel_name = f"deploy-{safe_user}"

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True
            ),
        }

        me = interaction.guild.me or interaction.guild.get_member(bot.user.id)
        if me:
            overwrites[me] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
                manage_channels=True
            )

        channel = await interaction.guild.create_text_channel(
            name=channel_name,
            overwrites=overwrites,
            reason=f"Canal de deploy criado para {interaction.user}"
        )

        sessions[channel.id] = {
            "user_id": interaction.user.id,
            "language": None
        }

        await channel.send(embed=build_deploy_step1_embed(interaction.user), view=LanguageView())
        await interaction.response.send_message(f"Canal criado: {channel.mention}", ephemeral=True)

    @discord.ui.button(label="📋 Meus Bots", style=discord.ButtonStyle.secondary)
    async def meus_bots(self, interaction: discord.Interaction, button: discord.ui.Button):
        user = ensure_user(interaction.user.id)
        bots_list = user["bots"]

        if not bots_list:
            await interaction.response.send_message("Você ainda não tem bots hospedados.", ephemeral=True)
            return

        embed = discord.Embed(
            title="📋 Meus bots",
            description="Escolha um bot na lista abaixo.",
            color=discord.Color.blurple()
        )
        embed.set_footer(text="Sistema de hospedagem • Beta")

        await interaction.response.send_message(
            embed=embed,
            view=BotsListView(interaction.user.id, bots_list),
            ephemeral=True
        )

    @discord.ui.button(label="🎭 Ver Planos", style=discord.ButtonStyle.success)
    async def ver_planos(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not DATA.get("plans_configured", False):
            await interaction.response.send_message("Os planos ainda não foram configurados.", ephemeral=True)
            return

        embed = discord.Embed(
            title="🎭 Planos",
            description=(
                "**Free** — 1 bot\n"
                "**Pro** — 5 bots\n"
                "**Ultra** — 10 bots"
            ),
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.event
async def on_ready():
    try:
        await bot.tree.sync()
    except Exception:
        pass
    print(f"Logado como {bot.user}")


@bot.tree.command(name="painel", description="Abrir o painel do host")
async def painel(interaction: discord.Interaction):
    embed = build_panel_embed()
    view = MainPanelView()

    if not DATA.get("plans_configured", False):
        for item in list(view.children):
            if isinstance(item, discord.ui.Button) and item.label == "🎭 Ver Planos":
                view.remove_item(item)
                break

    await interaction.response.send_message(embed=embed, view=view)


@bot.command(name="painel")
async def painel_prefix(ctx: commands.Context):
    embed = build_panel_embed()
    view = MainPanelView()

    if not DATA.get("plans_configured", False):
        for item in list(view.children):
            if isinstance(item, discord.ui.Button) and item.label == "🎭 Ver Planos":
                view.remove_item(item)
                break

    await ctx.send(embed=embed, view=view)


@bot.command(name="configplanos")
@commands.has_permissions(administrator=True)
async def config_planos(ctx: commands.Context, estado: str = "on"):
    valor = estado.lower() in ("on", "true", "1", "sim", "yes")
    DATA["plans_configured"] = valor
    save_data()
    await ctx.send(f"Configuração de planos: {'ativada' if valor else 'desativada'}.")


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    if isinstance(message.channel, discord.TextChannel) and message.channel.id in sessions:
        session = sessions[message.channel.id]

        if message.author.id != session["user_id"]:
            await message.channel.send("Só o dono deste canal pode enviar o arquivo.")
            return

        if message.attachments:
            attachment = message.attachments[0]
            filename = attachment.filename.lower()

            if not (filename.endswith(".zip") or filename.endswith(".rar")):
                await message.channel.send("Envie um arquivo **.zip** ou **.rar**.")
                return

            user_id = message.author.id
            user_data = ensure_user(user_id)

            bot_number = len(user_data["bots"]) + 1
            bot_id = f"bot{bot_number}"
            bot_name = f"{sanitize_name(message.author.name)}-{bot_id}"

            folder = os.path.join(BASE_PATH, str(user_id), bot_id)
            os.makedirs(folder, exist_ok=True)

            archive_path = os.path.join(folder, attachment.filename)
            await attachment.save(archive_path)

            try:
                extract_archive(archive_path, folder)
                os.remove(archive_path)
            except Exception as e:
                await message.channel.send(f"Erro ao extrair arquivo: {e}")
                return

            record = {
                "id": bot_id,
                "name": bot_name,
                "language": session.get("language", "desconhecida"),
                "folder": folder,
                "status": "stopped",
                "created_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
            }

            found_py = find_any_py(folder)
            if found_py:
                record["entry"] = found_py

            user_data["bots"].append(record)
            save_data()

            await message.channel.send(
                f"✅ Bot **{bot_name}** salvo com sucesso.\n"
                f"Arquivo detectado: `{os.path.basename(found_py) if found_py else 'nenhum .py encontrado'}`\n"
                f"Agora vá em **Meus Bots** para ver os controles."
            )
            return

    await bot.process_commands(message)


@config_planos.error
async def config_planos_error(ctx: commands.Context, error: Exception):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("Você precisa ser administrador para usar esse comando.")
    else:
        await ctx.send(f"Erro: {error}")


bot.run(TOKEN)